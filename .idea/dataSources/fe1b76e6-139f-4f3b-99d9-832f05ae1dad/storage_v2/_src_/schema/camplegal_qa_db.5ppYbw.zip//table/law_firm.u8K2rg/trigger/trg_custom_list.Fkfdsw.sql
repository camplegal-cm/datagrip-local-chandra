create definer = root@localhost trigger trg_custom_list
    after insert
    on law_firm
    for each row
    call load_custom_lists(NEW.id);

