create
    definer = root@localhost procedure proc_copy_answers(IN p_law_firm_id bigint, IN p_to_case_id bigint, IN p_petitioner_id bigint, IN p_created_at datetime)
begin


    delete a1
    from answer a1
             inner join (select distinct p_created_at,
                                         p_law_firm_id,
                                         p_petitioner_id,
                                         p_to_case_id,/*distinct coalesce(a.last_modified_at,a.created_at) as last_date*/
                                         a.question_id,
                                         text latest_answer,
                                         'COPY_ANSWER'
                         from answer a,
                              (select max(coalesce(last_modified_at, created_at)) as mdate, question_id
                               from answer
                               where law_firm = p_law_firm_id
                                 and petitioner_id = p_petitioner_id
                               group by question_id) b,
                              (select coalesce(last_modified_at, created_at) as bbdate, max(text) mtext, question_id
                               from answer
                               where law_firm = p_law_firm_id
                                 and petitioner_id = p_petitioner_id
                               group by question_id, bbdate) bb,
                              icase c
                         where COALESCE(a.last_modified_at, a.created_at) = b.mdate
                           and a.question_id = b.question_id
                           and a.text = bb.mtext
                           and a.question_id = bb.question_id
                           and coalesce(a.last_modified_at, a.created_at) = bb.bbdate
                           and c.law_firm = p_law_firm_id
                           and a.law_firm = c.law_firm
                           and a.case_id = c.id
                           and c.case_status not in ('DELETED')
                           and a.petitioner_id = p_petitioner_id
                         order by a.question_id) d on
                a1.law_firm = d.p_law_firm_id
            and a1.question_id = d.question_id
            and a1.case_id = d.p_to_case_id
            and a1.petitioner_id = d.p_petitioner_id;


    # delete
# from answer
# where law_firm = p_law_firm_id
#   and case_id = p_to_case_id
#   and petitioner_id = p_petitioner_id
#   and question_id in (
#     select distinct a.question_id
#     from answer a,
#          (select max(coalesce(last_modified_at, created_at)) as mdate, question_id
#           from answer
#           where law_firm = p_law_firm_id
#             and petitioner_id = p_petitioner_id
#           group by question_id) b,
#          (select coalesce(last_modified_at, created_at) as bbdate, max(text) mtext, question_id
#           from answer
#           where law_firm = p_law_firm_id
#             and petitioner_id = p_petitioner_id
#           group by question_id, bbdate) bb,
#          icase c
#     where COALESCE(a.last_modified_at, a.created_at) = b.mdate
#       and a.question_id = b.question_id
#       and a.text = bb.mtext
#       and a.question_id = bb.question_id
#       and coalesce(a.last_modified_at, a.created_at) = bb.bbdate
#       and c.law_firm = p_law_firm_id
#       and a.law_firm = c.law_firm
#       and a.case_id = c.id
#       and c.case_status not in ('DELETED')
#       and a.petitioner_id = p_petitioner_id
#     order by a.question_id
# );
    insert into answer(created_at, law_firm, petitioner_id, case_id, question_id, text, created_process)
    select distinct p_created_at,
                    p_law_firm_id,
                    p_petitioner_id,
                    p_to_case_id,/*distinct coalesce(a.last_modified_at,a.created_at) as last_date*/
                    a.question_id,
                    text latest_answer,
                    'COPY_ANSWER'
    from answer a,
         (select max(coalesce(last_modified_at, created_at)) as mdate, question_id
          from answer
          where law_firm = p_law_firm_id
            and petitioner_id = p_petitioner_id
          group by question_id) b,
         (select coalesce(last_modified_at, created_at) as bbdate, max(text) mtext, question_id
          from answer
          where law_firm = p_law_firm_id
            and petitioner_id = p_petitioner_id
          group by question_id, bbdate) bb,
         icase c
    where COALESCE(a.last_modified_at, a.created_at) = b.mdate
      and a.question_id = b.question_id
      and a.text = bb.mtext
      and a.question_id = bb.question_id
      and coalesce(a.last_modified_at, a.created_at) = bb.bbdate
      and c.law_firm = p_law_firm_id
      and a.law_firm = c.law_firm
      and a.case_id = c.id
      and c.case_status not in ('DELETED')
      and a.petitioner_id = p_petitioner_id
    order by a.question_id;

end;

