create view vw_main_search as
select distinct (upper(concat(`a`.`law_firm`, '~~', coalesce(`a`.`first_name`, ''), '~~', coalesce(`a`.`middle_name`, ''), '~~', coalesce(`a`.`last_name`, ''), '~~', coalesce(`a`.`name`, ''), '~~', coalesce(`a`.`a_number`, ''), '~~',
                              coalesce(`a`.`phone`, ''), '~~', convert(coalesce(`b`.`case_number`, '') using utf8mb4), '~~', coalesce(`c`.`invoice_number`, ''), '~~', convert(coalesce(`c`.`reference`, '') using utf8mb4), '~~',
                              convert(coalesce(`cb`.`relationship`, '') using utf8mb4), '~~', convert(coalesce(`cb`.`beneficiary_type`, '') using utf8mb4))) collate utf8mb4_unicode_ci) AS `search_key`,
                `a`.`id`                                                                                                                                                                 AS `person_id`,
                `a`.`law_firm`                                                                                                                                                           AS `law_firm`,
                coalesce(`a`.`first_name`, '')                                                                                                                                           AS `first_name`,
                coalesce(`a`.`middle_name`, '')                                                                                                                                          AS `middle_name`,
                coalesce(`a`.`last_name`, '')                                                                                                                                            AS `last_name`,
                coalesce(`a`.`name`, '')                                                                                                                                                 AS `company_name`,
                `a`.`person_type`                                                                                                                                                        AS `person_type`,
                coalesce(`a`.`a_number`, '')                                                                                                                                             AS `a_number`,
                coalesce(`a`.`phone`, '')                                                                                                                                                AS `phone`,
                `b`.`id`                                                                                                                                                                 AS `case_id`,
                coalesce(`b`.`case_number`, '')                                                                                                                                          AS `case_number`,
                `c`.`id`                                                                                                                                                                 AS `invoice_id`,
                coalesce(`c`.`invoice_number`, '')                                                                                                                                       AS `invoice_number`,
                coalesce(`c`.`reference`, '')                                                                                                                                            AS `reference`,
                coalesce(`c`.`reference`, convert(concat('INV-', lpad(`c`.`invoice_number`, 10, '0')) using latin1))                                                                     AS `Invoice_number_formatted`,
                coalesce(`cb`.`relationship`, '')                                                                                                                                        AS `relationship`,
                coalesce(`cb`.`beneficiary_type`)                                                                                                                                        AS `beneficiary_type`,
                coalesce(`p`.`name`, '')                                                                                                                                                 AS `petition_name`,
                coalesce(`p`.`description`, '')                                                                                                                                          AS `petition_description`
from (((((`camplegal_qa_db`.`law_firm` `l` left join `camplegal_qa_db`.`person` `a` on ((`l`.`id` = `a`.`law_firm`))) left join `camplegal_qa_db`.`icase` `b` on (((`a`.`id` = `b`.`client`) and (`l`.`id` = `b`.`law_firm`)))) left join `camplegal_qa_db`.`invoice` `c` on (((`a`.`id` = `c`.`invoiced_to`) and (`l`.`id` = `c`.`law_firm`)))) left join `camplegal_qa_db`.`case_beneficiary` `cb` on (((`b`.`id` = `cb`.`icase`) and (`b`.`client` = `cb`.`dependent_of`))))
         left join `camplegal_qa_db`.`petition` `p` on ((`b`.`petition` = `p`.`id`)));

