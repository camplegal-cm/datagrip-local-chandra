
CREATE TRIGGER ClientCustomDocuments_OnDelete ON ClientCustomDocuments AFTER DELETE AS
    INSERT INTO DeletedFiles (Name, DeletionDate)
    SELECT concat('ClientCustomDocuments/', ClientCustomDocumentID), GetUTCDate()
    FROM DELETED
    WHERE FileStorageLocationID=3
go

