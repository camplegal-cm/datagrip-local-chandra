
CREATE TRIGGER ClientI94s_OnDelete ON ClientI94s AFTER DELETE AS
    INSERT INTO DeletedFiles (Name, DeletionDate)
    SELECT concat('ClientI94s/', ClientI94ID), GetUTCDate()
    FROM DELETED
    WHERE FileStorageLocationID=3
go

