CREATE DEFINER = root@localhost TRIGGER trg_upd_lead_lifecycle
    AFTER UPDATE
    ON `lead`
    FOR EACH ROW
begin
    if (OLD.status <> NEW.status) then
        select id, contact_type into @person_id, @contact_type from person where id = NEW.person_id;
        insert into client_lifecycle(law_firm_id, lead_id, lead_status, person_id, contact_type) values (NEW.law_firm_id, NEW.id, NEW.status, @person_id, @contact_type);
    end if;
end;

