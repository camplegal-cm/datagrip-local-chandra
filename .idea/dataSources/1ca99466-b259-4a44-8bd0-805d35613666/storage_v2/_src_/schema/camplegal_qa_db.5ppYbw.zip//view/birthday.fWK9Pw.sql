CREATE DEFINER = root@localhost VIEW birthday AS
SELECT `birthday_temp`.`id` AS `id`, `birthday_temp`.`law_firm` AS `law_firm`, `birthday_temp`.`first_name` AS `first_name`, `birthday_temp`.`last_name` AS `last_name`, `birthday_temp`.`email` AS `email`, `birthday_temp`.`phone` AS `phone`, `birthday_temp`.`city` AS `city`,
       `birthday_temp`.`state` AS `state`, `birthday_temp`.`country` AS `country`, `birthday_temp`.`zip` AS `zip`, `birthday_temp`.`is_current` AS `is_current`
FROM `camplegal_qa_db`.`birthday_temp`
WHERE (`birthday_temp`.`is_current` = 'Yes');

