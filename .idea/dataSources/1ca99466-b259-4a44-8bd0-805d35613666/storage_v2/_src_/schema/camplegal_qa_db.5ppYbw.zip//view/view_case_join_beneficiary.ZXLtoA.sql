CREATE DEFINER = root@localhost VIEW view_case_join_beneficiary AS
SELECT `a1`.`id` AS `id`, `a1`.`created_at` AS `created_at`, `a1`.`case_number` AS `case_number`, `a1`.`client` AS `client`, `a1`.`sponsor_type` AS `sponsor_type`, `a1`.`file_id` AS `file_id`, `a1`.`petition` AS `petition`, `a1`.`case_status` AS `case_status`, `a1`.`law_firm` AS `law_firm`,
       `a1`.`company` AS `company`, `a1`.`last_accessed_at` AS `last_accessed_at`, `a1`.`preparer` AS `preparer`, `a1`.`questionnaire_status` AS `questionnaire_status`, `a1`.`case_venue` AS `case_venue`, `a1`.`import_id` AS `import_id`, `a1`.`import_system_name` AS `import_system_name`,
       `a1`.`client_display_name` AS `client_display_name`, `a1`.`interpreter` AS `interpreter`, `a1`.`uuid` AS `uuid`, `a1`.`migration_note` AS `migration_note`, `a2`.`beneficiary` AS `sbeneficiary`
FROM (`camplegal_qa_db`.`icase` `a1` JOIN `camplegal_qa_db`.`case_beneficiary` `a2` ON (((`a1`.`id` = `a2`.`icase`) AND (`a2`.`beneficiary_type` = 0))));

