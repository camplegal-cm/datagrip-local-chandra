CREATE DEFINER = root@localhost TRIGGER trg_case_timeline
    AFTER UPDATE
    ON icase
    FOR EACH ROW
begin
    if (new.case_status <> old.case_status) then
        insert into case_timeline(law_firm_id, case_id, instant, activity) VALUES (old.law_firm, old.id, now(), new.case_status);
    end if;
end;

