CREATE DEFINER = root@localhost TRIGGER trg_new_case_timeline
    AFTER INSERT
    ON icase
    FOR EACH ROW
begin
    insert into case_timeline(law_firm_id, case_id, instant, activity) VALUES (new.law_firm, new.id, now(), new.case_status);
end;

