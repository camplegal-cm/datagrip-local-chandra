CREATE DEFINER = root@localhost TRIGGER trg_custom_list
    AFTER INSERT
    ON law_firm
    FOR EACH ROW
    call load_custom_lists(NEW.id);

