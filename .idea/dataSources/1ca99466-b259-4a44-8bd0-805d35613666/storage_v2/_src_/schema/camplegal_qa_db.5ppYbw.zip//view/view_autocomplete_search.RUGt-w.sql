CREATE DEFINER = root@localhost VIEW view_autocomplete_search AS
SELECT DISTINCT (UCASE(CONCAT(`a`.`law_firm`, '~~', COALESCE(`a`.`first_name`, ''), '~~', COALESCE(`a`.`middle_name`, ''), '~~', COALESCE(`a`.`last_name`, ''), '~~', COALESCE(`a`.`name`, ''), '~~', COALESCE(`a`.`a_number`, ''), '~~', COALESCE(`a`.`phone`, ''), '~~',
                              CONVERT(COALESCE(`b`.`case_number`, '') USING utf8mb4))) COLLATE utf8mb4_unicode_ci) AS `search_key`, `a`.`id` AS `personId`, `a`.`law_firm` AS `law_firm`, COALESCE(`a`.`first_name`, '') AS `firstName`, COALESCE(`a`.`middle_name`, '') AS `middleName`,
                COALESCE(`a`.`last_name`, '') AS `lastName`, COALESCE(`a`.`name`, '') AS `companyName`, `a`.`person_type` AS `personType`, `a`.`contact_type` AS `contactType`, COALESCE(`a`.`a_number`, '') AS `aNumber`, COALESCE(`a`.`phone`, '') AS `phone`, COALESCE(`a`.`filename`, '') AS `fileName`,
                COALESCE(`a`.`email`, '') AS `email`, COALESCE(`b`.`id`, '') AS `caseId`, COALESCE(`b`.`case_number`, '') AS `caseNumber`, COALESCE(`b`.`last_accessed_at`, '') AS `lastAccessedAt`, COALESCE(`b`.`case_status`, '') AS `caseStatus`, COALESCE(`b`.`case_venue`, '') AS `caseVenue`,
                COALESCE(`c`.`id`, '') AS `invoiceId`, COALESCE(`c`.`invoice_number`, '') AS `invoiceNumber`, COALESCE(`c`.`reference`, '') AS `reference`, COALESCE(`c`.`reference`, CONVERT(CONCAT('INV-', LPAD(`c`.`invoice_number`, 10, '0')) USING latin1), '') AS `formattedInvoiceNumber`,
                `c`.`amount` AS `invoiceAmount`, COALESCE(`c`.`due_by`, '') AS `dueDate`, COALESCE(`c`.`invoice_status`, '') AS `invoiceStatus`, COALESCE(`c`.`invoice_type`, '') AS `invoiceType`, COALESCE(`cb`.`relationship`, '') AS `relationship`,
                COALESCE(`cb`.`beneficiary_type`, '') AS `beneficiaryType`, (CASE WHEN (COALESCE(`cb`.`id`, 0) = 0) THEN '' ELSE REPLACE(CONCAT(COALESCE(`a`.`first_name`, ''), ' ', COALESCE(`a`.`middle_name`, ''), ' ', COALESCE(`a`.`last_name`, '')), '  ', ' ') END) AS `beneficiaryName`,
                COALESCE(`p`.`name`, '') AS `petitionName`, COALESCE(`p`.`description`, '') AS `petitionDescription`
FROM (((((`camplegal_qa_db`.`law_firm` `l` LEFT JOIN `camplegal_qa_db`.`person` `a` ON ((`l`.`id` = `a`.`law_firm`))) LEFT JOIN `camplegal_qa_db`.`icase` `b` ON (((`a`.`id` = `b`.`client`) AND (`l`.`id` = `b`.`law_firm`)))) LEFT JOIN `camplegal_qa_db`.`invoice` `c`
        ON (((`a`.`id` = `c`.`invoiced_to`) AND (`l`.`id` = `c`.`law_firm`)))) LEFT JOIN `camplegal_qa_db`.`case_beneficiary` `cb` ON (((`l`.`id` = `cb`.`law_firm`) AND (`b`.`id` = `cb`.`icase`) AND (`cb`.`beneficiary_type` = 0)))) LEFT JOIN `camplegal_qa_db`.`petition` `p`
      ON ((`b`.`petition` = `p`.`id`)))
WHERE (1 = (CASE WHEN (ISNULL(`cb`.`beneficiary_type`) AND ISNULL(`b`.`id`)) THEN 0 ELSE 1 END))
UNION
SELECT DISTINCT (UCASE(CONCAT(`a`.`law_firm`, '~~', COALESCE(`a`.`first_name`, ''), '~~', COALESCE(`a`.`middle_name`, ''), '~~', COALESCE(`a`.`last_name`, ''), '~~', COALESCE(`a`.`name`, ''), '~~', COALESCE(`a`.`a_number`, ''), '~~', COALESCE(`a`.`phone`, ''), '~~',
                              CONVERT(COALESCE(`b`.`case_number`, '') USING utf8mb4))) COLLATE utf8mb4_unicode_ci) AS `search_key`, `a`.`id` AS `personId`, `a`.`law_firm` AS `law_firm`, COALESCE(`a`.`first_name`, '') AS `firstName`, COALESCE(`a`.`middle_name`, '') AS `middleName`,
                COALESCE(`a`.`last_name`, '') AS `lastName`, COALESCE(`a`.`name`, '') AS `companyName`, COALESCE(`a`.`person_type`, '') AS `personType`, COALESCE(`a`.`contact_type`, '') AS `contactType`, COALESCE(`a`.`a_number`, '') AS `aNumber`, COALESCE(`a`.`phone`, '') AS `phone`,
                COALESCE(`a`.`filename`, '') AS `fileName`, COALESCE(`a`.`email`, '') AS `email`, COALESCE(`b`.`id`, '') AS `caseId`, COALESCE(`b`.`case_number`, '') AS `caseNumber`, COALESCE(`b`.`last_accessed_at`, '') AS `lastAccessedAt`, COALESCE(`b`.`case_status`, '') AS `caseStatus`,
                COALESCE(`b`.`case_venue`, '') AS `caseVenue`, '' AS `invoiceId`, '' AS `invoiceNumber`, '' AS `reference`, '' AS `formattedInvoiceNumber`, NULL AS `invoiceAmount`, '' AS `dueDate`, '' AS `invoiceStatus`, '' AS `invoiceType`, '' AS `relationship`, '' AS `beneficiaryType`,
                '' AS `beneficiaryName`, '' AS `petitionName`, '' AS `petitionDescription`
FROM (((`camplegal_qa_db`.`law_firm` `l` LEFT JOIN `camplegal_qa_db`.`person` `a` ON ((`l`.`id` = `a`.`law_firm`))) LEFT JOIN `camplegal_qa_db`.`icase` `b` ON (((`a`.`id` = `b`.`client`) AND (`l`.`id` = `b`.`law_firm`)))) LEFT JOIN `camplegal_qa_db`.`case_beneficiary` `cb`
      ON (((`l`.`id` = `cb`.`law_firm`) AND ((`a`.`id` = `cb`.`beneficiary`) OR (`a`.`id` = `cb`.`dependent_of`)))))
WHERE (ISNULL(`b`.`id`) AND ISNULL(`cb`.`icase`));

