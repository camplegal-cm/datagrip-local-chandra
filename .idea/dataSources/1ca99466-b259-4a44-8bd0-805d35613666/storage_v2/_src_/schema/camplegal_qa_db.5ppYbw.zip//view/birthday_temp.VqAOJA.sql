CREATE DEFINER = root@localhost VIEW birthday_temp AS
SELECT `camplegal_qa_db`.`person`.`id` AS `id`, `camplegal_qa_db`.`person`.`law_firm` AS `law_firm`, `camplegal_qa_db`.`person`.`first_name` AS `first_name`, `camplegal_qa_db`.`person`.`last_name` AS `last_name`, `camplegal_qa_db`.`person`.`email` AS `email`,
       `camplegal_qa_db`.`person`.`phone` AS `phone`, `camplegal_qa_db`.`person`.`city` AS `city`, `camplegal_qa_db`.`person`.`state` AS `state`, `camplegal_qa_db`.`person`.`country` AS `country`, `camplegal_qa_db`.`person`.`zip` AS `zip`,
       (CASE WHEN ((MONTH(`camplegal_qa_db`.`person`.`date_of_birth`) = MONTH(CURDATE())) AND (DAYOFMONTH(CURDATE()) = DAYOFMONTH(`camplegal_qa_db`.`person`.`date_of_birth`))) THEN 'Yes' ELSE 'No' END) AS `is_current`
FROM `camplegal_qa_db`.`person`;

