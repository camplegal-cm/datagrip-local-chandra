create
    definer = rdsadmin@localhost procedure rds_import_binlog_ssl_material(IN cert_payload text)
BEGIN

    IF @@rds_ebr_import_in_progress = true THEN

        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'SSL material import already in progress.';
    
    END IF;

    SET GLOBAL rds_ebr_import_in_progress = true; 

    BEGIN

        DECLARE EXIT HANDLER FOR SQLEXCEPTION 
        BEGIN

            SELECT 'An error occurred.' as Message;
            SET GLOBAL rds_ebr_import_in_progress = false;
    
        END;

        CALL ACTION ebr_clear_ssl_material();
        SET GLOBAL rds_ebr_ssl_material = cert_payload;

        CALL ACTION ebr_setup_ssl_material();

        IF @@rds_ebr_ssl_ca IS NULL OR @@rds_ebr_ssl_cert IS NULL OR @@rds_ebr_ssl_key IS NULL THEN

            CALL ACTION ebr_clear_ssl_material();
            SET GLOBAL rds_ebr_import_in_progress = false; 

            SELECT CONCAT('SSL material import failed (',
            CONCAT_WS(', ', 
                IF(@@rds_ebr_ssl_ca IS NULL, 'Empty/invalid SSL CA', NULL), 
                IF(@@rds_ebr_ssl_cert IS NULL, 'Empty/invalid SSL Cert', NULL), 
                IF(@@rds_ebr_ssl_key IS NULL, 'Empty/invalid SSL Key', NULL)
            ), 
            '). See documentation for details.')INTO @tmp_message; 

            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = @tmp_message;

        END IF;

        SET @@sql_log_bin=off;

        DROP TEMPORARY TABLE IF EXISTS `mysql`.`rds_ebr_ssl_material`;

        CREATE TEMPORARY TABLE `mysql`.`rds_ebr_ssl_material` (
            ssl_ca TEXT DEFAULT NULL,
            ssl_cert TEXT DEFAULT NULL,
            ssl_key TEXT DEFAULT NULL
        ) ENGINE = InnoDB;

        select concat('_', current_timestamp() + 0) into @tmp;
        set global rds_ebr_ssl_file_suffix = @tmp;

        INSERT INTO `mysql`.`rds_ebr_ssl_material` (ssl_ca, ssl_cert, ssl_key) VALUES (@@rds_ebr_ssl_ca, @@rds_ebr_ssl_cert, @@rds_ebr_ssl_key);

        SET @cmd = CONCAT('SELECT ssl_ca INTO DUMPFILE \'/tmp/sslreplication/ssl_ca', @@rds_ebr_ssl_file_suffix, '.pem\' FROM `mysql`.`rds_ebr_ssl_material`');
        PREPARE rds_dump_cert FROM @cmd;
        EXECUTE rds_dump_cert;

        SET @cmd = CONCAT('SELECT ssl_cert INTO DUMPFILE \'/tmp/sslreplication/ssl_cert', @@rds_ebr_ssl_file_suffix, '.pem\' FROM `mysql`.`rds_ebr_ssl_material`');
        PREPARE rds_dump_cert FROM @cmd;
        EXECUTE rds_dump_cert;

        SET @cmd = CONCAT('SELECT ssl_key INTO DUMPFILE \'/tmp/sslreplication/ssl_key', @@rds_ebr_ssl_file_suffix, '.pem\' FROM `mysql`.`rds_ebr_ssl_material`');
        PREPARE rds_dump_cert FROM @cmd;
        EXECUTE rds_dump_cert;

        DROP TEMPORARY TABLE IF EXISTS `mysql`.`rds_ebr_ssl_material`;
        CALL ACTION ebr_clear_ssl_material();

        CALL ACTION ebr_import_ssl_material();
        CALL ACTION ebr_export_ssl_material();

        SET @@sql_log_bin=on;
        SET GLOBAL rds_ebr_import_in_progress = false; 
        SET GLOBAL rds_ebr_ssl_file_suffix = "";
        SELECT 'SSL material import complete.' AS Message;

    END;
END;

