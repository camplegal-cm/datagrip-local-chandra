create
    definer = rdsadmin@localhost procedure lambda_async(IN functionName varchar(1600), IN inputPayload varchar(65535)) deterministic reads sql data
BEGIN
   AWSLAMBDA(functionName,inputPayload,'0');
END;

