create definer = rdsadmin@localhost trigger block_proc_i
    before insert
    on proc
    for each row
BEGIN
   IF new.Definer = 'rdsadmin@localhost' and USER() not in ('rdsadmin@localhost','','rdsadmin@connecting host') THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'CANNOT MODIFY RDSADMIN OBJECT';
   END IF;
END;

