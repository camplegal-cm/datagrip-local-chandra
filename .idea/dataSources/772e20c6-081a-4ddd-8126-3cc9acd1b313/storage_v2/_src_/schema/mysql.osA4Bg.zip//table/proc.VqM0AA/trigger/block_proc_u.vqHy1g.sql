create definer = rdsadmin@localhost trigger block_proc_u
    before update
    on proc
    for each row
BEGIN
DECLARE foo varchar(255);
if old.Definer = "rdsadmin@localhost" then
  select `ERROR (RDS): CANNOT MODIFY RDSDMIN OBJECT` into foo;
end if;
END;

