create definer = rdsadmin@localhost event ev_rds_gsh_collector on schedule
    every '5' MINUTE
        starts '2013-10-07 10:09:26'
    on completion preserve
    disable
    do
    CALL rds_collect_global_status_history();

