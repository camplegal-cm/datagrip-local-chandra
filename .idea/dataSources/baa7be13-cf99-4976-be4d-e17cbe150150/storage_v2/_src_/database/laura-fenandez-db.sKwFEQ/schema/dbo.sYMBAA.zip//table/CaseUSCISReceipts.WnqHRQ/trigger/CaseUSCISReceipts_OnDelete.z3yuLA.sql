
CREATE TRIGGER CaseUSCISReceipts_OnDelete ON CaseUSCISReceipts AFTER DELETE AS
    INSERT INTO DeletedFiles (Name, DeletionDate)
    SELECT concat('CaseUSCISReceipts/', CaseUSCISReceiptID), GetUTCDate()
    FROM DELETED
    WHERE FileStorageLocationID=3
go

