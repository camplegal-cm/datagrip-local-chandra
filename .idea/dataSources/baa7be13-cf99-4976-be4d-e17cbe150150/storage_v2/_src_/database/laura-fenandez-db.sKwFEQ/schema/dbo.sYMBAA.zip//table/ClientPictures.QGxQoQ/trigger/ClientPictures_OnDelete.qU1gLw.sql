
CREATE TRIGGER ClientPictures_OnDelete ON ClientPictures AFTER DELETE AS
    INSERT INTO DeletedFiles (Name, DeletionDate)
    SELECT concat('ClientPictures/', ClientPictureID), GetUTCDate()
    FROM DELETED
    WHERE FileStorageLocationID=3
go

