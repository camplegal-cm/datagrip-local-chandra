
CREATE TRIGGER InternalEmailDocuments_OnDelete ON InternalEmailDocuments AFTER DELETE AS
    INSERT INTO DeletedFiles (Name, DeletionDate)
    SELECT concat('InternalEmailDocuments/', InternalEmailDocumentID), GetUTCDate()
    FROM DELETED
    WHERE FileStorageLocationID=3
go

