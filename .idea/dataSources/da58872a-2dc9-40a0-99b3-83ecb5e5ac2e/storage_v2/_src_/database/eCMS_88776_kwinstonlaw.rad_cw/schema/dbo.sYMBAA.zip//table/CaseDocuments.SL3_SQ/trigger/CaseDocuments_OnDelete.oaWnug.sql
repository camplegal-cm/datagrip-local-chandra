
CREATE TRIGGER CaseDocuments_OnDelete ON CaseDocuments AFTER DELETE AS
    INSERT INTO DeletedFiles (Name, DeletionDate)
    SELECT concat('CaseDocuments/', CaseDocumentID), GetUTCDate()
    FROM DELETED
    WHERE FileStorageLocationID=3
go

