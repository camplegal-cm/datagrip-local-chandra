
CREATE TRIGGER ClientVisas_OnDelete ON ClientVisas AFTER DELETE AS
    INSERT INTO DeletedFiles (Name, DeletionDate)
    SELECT concat('ClientVisas/', ClientVisaID), GetUTCDate()
    FROM DELETED
    WHERE FileStorageLocationID=3
go

