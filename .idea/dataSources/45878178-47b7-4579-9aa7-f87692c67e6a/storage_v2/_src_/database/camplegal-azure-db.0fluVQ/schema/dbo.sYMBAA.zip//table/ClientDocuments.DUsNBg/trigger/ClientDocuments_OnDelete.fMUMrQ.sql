
CREATE TRIGGER ClientDocuments_OnDelete ON ClientDocuments AFTER DELETE AS
    INSERT INTO DeletedFiles (Name, DeletionDate)
    SELECT concat('ClientDocuments/', ClientDocumentID), GetUTCDate()
    FROM DELETED
    WHERE FileStorageLocationID=3
go

