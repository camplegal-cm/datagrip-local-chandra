create definer = admin@`%` trigger trg_upd_case_timeline
    after update
    on icase
    for each row
begin
    if (new.case_status <> old.case_status) then
        insert into case_timeline(law_firm_id, case_id, instant, activity) VALUES (old.law_firm, old.id, now(), new.case_status);
    end if;
end;

