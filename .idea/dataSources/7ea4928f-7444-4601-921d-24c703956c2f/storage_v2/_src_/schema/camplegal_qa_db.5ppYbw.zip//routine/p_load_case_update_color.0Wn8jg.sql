create
    definer = admin@`%` procedure p_load_case_update_color()
begin

    declare v_law_firm_id bigint;
    declare finished integer default 0;
    declare law_firm_cursor cursor for select coalesce(id, 0) from law_firm;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET finished = 1;
    open law_firm_cursor;
    insertDone:
    loop
        fetch law_firm_cursor into v_law_firm_id;
        if (finished = 1) then
            leave insertDone;
        end if;
        insert into custom_list(created_at, law_firm_id, type, text, color)
        values (now(), v_law_firm_id, 'CASE_UPDATE', 'Blue', '#2996cc');
        insert into custom_list(created_at, law_firm_id, type, text, color)
        values (now(), v_law_firm_id, 'CASE_UPDATE', 'Green', '#28a745');
        insert into custom_list(created_at, law_firm_id, type, text, color)
        values (now(), v_law_firm_id, 'CASE_UPDATE', 'Orange', '#F8AC59');
        insert into custom_list(created_at, law_firm_id, type, text, color)
        values (now(), v_law_firm_id, 'CASE_UPDATE', 'Red', '#EF5352');
        insert into custom_list(created_at, law_firm_id, type, text, color)
        values (now(), v_law_firm_id, 'CASE_UPDATE', 'Grey', '#cbd4da');
        set v_law_firm_id = 0;
    end loop insertDone;
    close law_firm_cursor;
end;

