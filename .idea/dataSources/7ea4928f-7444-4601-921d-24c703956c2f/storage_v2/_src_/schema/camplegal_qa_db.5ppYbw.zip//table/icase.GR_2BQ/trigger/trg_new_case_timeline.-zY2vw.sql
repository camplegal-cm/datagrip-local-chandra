create definer = admin@`%` trigger trg_new_case_timeline
    after insert
    on icase
    for each row
begin
    insert into case_timeline(law_firm_id, case_id, instant, activity) VALUES (new.law_firm, new.id, now(), new.case_status);
end;

