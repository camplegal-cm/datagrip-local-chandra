create
    definer = admin@`%` procedure p_enable_case_status_montoring()
begin

    declare v_law_firm_id bigint;
    declare finished integer default 0;
    declare law_firm_cursor cursor for select coalesce(id, 0) from law_firm;
    declare continue handler for not found set finished = 1;
    open law_firm_cursor;
    insertdone:
    loop
        fetch law_firm_cursor into v_law_firm_id;
        if (finished = 1) then leave insertdone; end if;
        insert into law_firm_preference(created_at, name, category, value, law_firm_id, sub_category)
        values (now(), 'Monitor', 'USCIS', 'enabled', v_law_firm_id, 'CASE_STATUS');
        set v_law_firm_id = 0;
    end loop insertdone;
    close law_firm_cursor;
end;

