create definer = admin@`%` trigger trg_ins_lead_lifecycle
    after insert
    on `lead`
    for each row
begin
    set @person_id = NULL;
    set @contact_type = 'Unknown';

    select id, contact_type into @person_id, @contact_type from person where id = NEW.person_id;
    insert into client_lifecycle(law_firm_id, lead_id, lead_status, person_id, contact_type) values (NEW.law_firm_id, NEW.id, NEW.status, @person_id, @contact_type);

end;

