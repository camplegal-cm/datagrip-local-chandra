create
    definer = rdsadmin@localhost procedure rds_set_external_master_with_auto_position(IN host varchar(255), IN port int, IN user text, IN passwd text, IN enable_ssl_encryption tinyint(1))
BEGIN
  DECLARE v_rdsrepl INT;
  DECLARE v_mysql_version VARCHAR(20);
  DECLARE v_called_by_user VARCHAR(50);
  DECLARE v_sleep int;
  DECLARE sql_logging BOOLEAN;
  DECLARE v_exit BOOLEAN DEFAULT FALSE;

  DECLARE EXIT HANDLER FOR 1105
  BEGIN
    SELECT 'Missing SSL Materials: please run mysql.rds_import_binlog_ssl_material first.' as Error;
    SET v_exit = TRUE;
  END;

  SET @regex = '.*"[[:space:]]*,[[:space:]]*[a-zA-Z_]+[[:space:]]*=[[:space:]]*".*';

  IF host REGEXP @regex
  OR user REGEXP @regex
  OR passwd REGEXP @regex THEN
    SELECT "Invalid arguments" as Message;
  ELSE
    select @@sql_log_bin into sql_logging;

    Select count(1) into v_rdsrepl from mysql.rds_history where action = 'disable set master' and master_user = 'rdsrepladmin';
    Select user() into v_called_by_user;
    select version() into v_mysql_version;
    set @@sql_log_bin=off;

    IF v_rdsrepl > 0 and v_called_by_user != 'rdsadmin@localhost' THEN
      Select 'RDS_SET_EXTERNAL_MASTER is disabled on this host.' as Message;
    ELSE
      IF enable_ssl_encryption = 1 THEN
        CALL ACTION ebr_export_ssl_material();
        SET @cmd = CONCAT('CHANGE MASTER TO ',
        CONCAT_WS(', ',
        CONCAT('MASTER_HOST = \'', trim(both from host), '\''),
        CONCAT('MASTER_PORT = ', port),
        CONCAT('MASTER_USER = \'', trim(both from user), '\''),
        CONCAT('MASTER_PASSWORD = \'', trim(both from passwd), '\''),
        CONCAT('MASTER_SSL = ', enable_ssl_encryption),
        CONCAT('MASTER_SSL_CA =  "/rdsdbdata/sslreplication/ssl_ca.pem"'),
        CONCAT('MASTER_SSL_CERT = "/rdsdbdata/sslreplication/ssl_cert.pem"'),
        CONCAT('MASTER_SSL_KEY = "/rdsdbdata/sslreplication/ssl_key.pem"'),
        CONCAT('MASTER_AUTO_POSITION = 1')));
      ELSE
        SET @cmd = CONCAT('CHANGE MASTER TO ',
        CONCAT_WS(', ',
        CONCAT('MASTER_HOST = \'', trim(both from host), '\''),
        CONCAT('MASTER_PORT = ', port),
        CONCAT('MASTER_USER = \'', trim(both from user), '\''),
        CONCAT('MASTER_PASSWORD = \'', trim(both from passwd), '\''),
        CONCAT('MASTER_SSL = ', enable_ssl_encryption),
        CONCAT('MASTER_SSL_CA =  \'\''),
        CONCAT('MASTER_SSL_CERT = \'\''),
        CONCAT('MASTER_SSL_KEY = \'\''),
        CONCAT('MASTER_AUTO_POSITION = 1')));
      END IF;

      PREPARE rds_set_master FROM @cmd;
      update mysql.rds_replication_status set called_by_user=v_called_by_user, action='set master', mysql_version=v_mysql_version , master_host=trim(both from host), master_port=port where action is not null;
      commit;

      BEGIN
        DECLARE CONTINUE HANDLER FOR 1105 BEGIN END;
        call action file_over_delete_relay_logs();
      END;

      EXECUTE rds_set_master;
      DEALLOCATE PREPARE rds_set_master;

      INSERT into mysql.rds_history(called_by_user, action, mysql_version, master_host, master_port, master_user, master_ssl, auto_position)
      values (v_called_by_user,'set master with AP', v_mysql_version, trim(both from host), port, trim(both from user), enable_ssl_encryption, 1);
      commit;
    END IF;

    set @@sql_log_bin=sql_logging;
  END IF;
END;

