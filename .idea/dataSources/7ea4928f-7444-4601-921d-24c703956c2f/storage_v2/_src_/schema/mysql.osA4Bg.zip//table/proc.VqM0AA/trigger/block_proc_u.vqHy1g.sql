create definer = rdsadmin@localhost trigger block_proc_u
    before update
    on proc
    for each row
BEGIN         IF old.Definer = 'rdsadmin@localhost' OR (old.Definer <> 'rdsadmin@localhost' AND new.Definer = 'rdsadmin@localhost') THEN                 SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'CANNOT MODIFY RDSADMIN OBJECT';           END IF;      END;

