create
    definer = rdsadmin@localhost procedure rds_skip_repl_error() deterministic reads sql data
BEGIN
  DECLARE v_threads_running int;
  DECLARE v_sleep int;
  SELECT COUNT(1) into v_threads_running FROM information_schema.processlist WHERE user = 'system user';
  if v_threads_running = 1 
  then
    STOP SLAVE;
    SET GLOBAL SQL_SLAVE_SKIP_COUNTER = 1;
    START SLAVE;
    Select 'Statement in error has been skipped' as Message;
    select sleep(2) into v_sleep;
    SELECT COUNT(1) into v_threads_running FROM information_schema.processlist WHERE user = 'system user';
    if v_threads_running = 2 then
      Select 'Slave is running normally' as Message;
    else
      Select 'Slave has encountered a new error. Please use SHOW SLAVE STATUS to see the error.' as Message;
    end if;
  elseif v_threads_running = 2 
  then
     Select 'Slave is running normally.  No errors detected to skip.' as Message;
  elseif v_threads_running = 0 
  then
     Select 'Slave is down or disabled.' as Message;
  end if;
END;

