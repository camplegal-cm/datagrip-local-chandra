create definer = rdsadmin@localhost event ev_rds_gsh_table_rotation on schedule
    every '7' DAY
        starts '2013-10-14 10:09:26'
    on completion preserve
    disable
    do
    CALL rds_rotate_global_status_history();

