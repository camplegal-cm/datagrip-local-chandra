create
    definer = rdsadmin@localhost procedure rds_set_master_auto_position(IN auto_position_mode tinyint(1))
BEGIN
  DECLARE v_threads_running INT;
  DECLARE v_sleep INT;
  DECLARE v_called_by_user VARCHAR(50);
  DECLARE v_mysql_version VARCHAR(20);
  DECLARE sql_logging BOOLEAN;

  SELECT @@sql_log_bin into sql_logging;
  SELECT user() into v_called_by_user;
  SELECT version() into v_mysql_version;
  SELECT COUNT(1) INTO v_threads_running FROM information_schema.processlist WHERE USER = 'system user';
  
  SET @@sql_log_bin=off;

  SET @cmd = CONCAT('CHANGE MASTER TO MASTER_AUTO_POSITION = ', auto_position_mode);
  STOP SLAVE;
  PREPARE rds_set_master FROM @cmd;
  EXECUTE rds_set_master;
  DEALLOCATE PREPARE rds_set_master;
  START SLAVE;
  SELECT CONCAT('Master Auto Position has been set to ', auto_position_mode,'.') AS Message;
  SELECT sleep(2) INTO v_sleep;
  SELECT COUNT(1) INTO v_threads_running FROM information_schema.processlist WHERE USER = 'system user';
  IF v_threads_running >= 2 THEN
    SELECT 'Slave is running normally' AS Message;
    INSERT into mysql.rds_history(called_by_user, action, mysql_version, auto_position) values (v_called_by_user,'set_master_AP:OK', v_mysql_version, auto_position_mode);
    commit;
  ELSE
    SELECT 'Slave has encountered a new error. Please use SHOW SLAVE STATUS to see the error.' AS Message;
    INSERT into mysql.rds_history(called_by_user, action, mysql_version, auto_position) values (v_called_by_user,'set_master_AP:ERR', v_mysql_version, auto_position_mode);
    commit;
  END IF;
  SET @@sql_log_bin=sql_logging;
END;

