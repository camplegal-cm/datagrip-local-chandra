create
    definer = rdsadmin@localhost procedure rds_skip_transaction_with_gtid(IN gtid_to_skip varchar(57))
BEGIN
  DECLARE v_threads_running int;
  DECLARE v_sleep int;
  DECLARE v_called_by_user VARCHAR(50);
  DECLARE v_mysql_version VARCHAR(20);
  DECLARE sql_logging BOOLEAN;
  select @@sql_log_bin into sql_logging;
  Select user() into v_called_by_user;
  Select version() into v_mysql_version;

  SET @regex = '^([[:alnum:]]+\\-){4}[[:alnum:]]+\\:[[:digit:]]+$';
  IF gtid_to_skip REGEXP @regex = 1
  THEN
    set @@sql_log_bin=off;
    SET GTID_NEXT=gtid_to_skip;
    START TRANSACTION;
    COMMIT;
    SET GTID_NEXT="AUTOMATIC";
    Select 'Transaction has been skipped successfully.' as Message;
    set @@sql_log_bin=off;
    INSERT into mysql.rds_history(called_by_user, action, mysql_version) values (v_called_by_user,'rds_skip_transaction_with_gtid:OK',v_mysql_version);
    commit;
    set @@sql_log_bin=sql_logging;
  ELSE
    SELECT "Invalid input GTID." as Message;
  END IF;

END;

