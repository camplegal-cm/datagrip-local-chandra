
CREATE TRIGGER CaseCustomReceipts_OnDelete ON CaseCustomReceipts AFTER DELETE AS
    INSERT INTO DeletedFiles (Name, DeletionDate)
    SELECT concat('CaseCustomReceipts/', CaseCustomReceiptID), GetUTCDate()
    FROM DELETED
    WHERE FileStorageLocationID=3
go

