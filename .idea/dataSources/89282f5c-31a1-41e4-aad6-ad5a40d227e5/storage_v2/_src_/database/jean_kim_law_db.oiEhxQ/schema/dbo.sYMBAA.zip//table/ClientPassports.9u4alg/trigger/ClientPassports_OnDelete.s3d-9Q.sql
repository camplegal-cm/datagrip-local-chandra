
CREATE TRIGGER ClientPassports_OnDelete ON ClientPassports AFTER DELETE AS
    INSERT INTO DeletedFiles (Name, DeletionDate)
    SELECT concat('ClientPassports/', ClientPassportID), GetUTCDate()
    FROM DELETED
    WHERE FileStorageLocationID=3
go

