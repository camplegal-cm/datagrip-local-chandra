
CREATE TRIGGER RealTimeJobs_OnDelete ON RealTimeJobs AFTER DELETE AS
    INSERT INTO DeletedFiles (Name, DeletionDate)
    SELECT concat('RealTimeJobs/', RealTimeJobID), GetUTCDate()
    FROM DELETED
    WHERE FileStorageLocationID=3
go

