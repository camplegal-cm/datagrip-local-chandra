
CREATE TRIGGER QuestionnaireDocuments_OnDelete ON QuestionnaireDocuments AFTER DELETE AS
    INSERT INTO DeletedFiles (Name, DeletionDate)
    SELECT concat('QuestionnaireDocuments/', QuestionnaireDocumentID), GetUTCDate()
    FROM DELETED
    WHERE FileStorageLocationID=3
go

